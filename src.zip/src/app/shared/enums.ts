export enum TargetStatus {
  Running = "Running",
  Stopped = "Stopped",
  MigrationFailed = "Failed",
  Unknown = "Unknown",
}
