import { Component, OnInit } from "@angular/core";
import { map } from "rxjs/operators";
import { TargetAsset } from "../models/target-asset.model";
import { DashboardServiceService } from "../services/dashboard-service.service";

@Component({
  selector: "app-dashboard",
  templateUrl: "dashboard.component.html",
  styleUrls: ["dashboard.component.css"],
})
export class DashboardComponent implements OnInit {
  targetAssets: TargetAsset[] = [];
  isFetching: boolean = false;

  constructor(private dashboardService: DashboardServiceService) {}

  ngOnInit(): void {
    this.isFetching = true;
    this.dashboardService
      .getMethod()
      .pipe(
        map((targets: TargetAsset[]) => {
          return targets.filter((x) => x != null);
        })
      )
      .subscribe((targets: TargetAsset[]) => {
        setTimeout(() => {
          this.isFetching = false;
        }, 2000);

        this.targetAssets = targets;

        console.log(this.targetAssets);
      });
  }

  getHighlight(status: string): string {
    let tempStatus = "";
    switch (status) {
      case "Running":
        tempStatus = "status-running";
        break;
      case "Stopped":
        tempStatus = "status-stopped";
        break;
      case "MigrationFailed":
        tempStatus = "status-failed";
        break;
      case "Unknown":
        tempStatus = "status-unknown";
        break;
    }
    return tempStatus;
  }
}
