describe("app.component.ts", () => {
  it("should return true", () => {
    expect(true).toBeTruthy();
  });
});
